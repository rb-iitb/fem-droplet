function [xnode,flux_node,mass_evap,pd,ed,td] = MainCode(r_drop)
%Define global parameters
global k_droplet L2 H2 n_cap TfreeSurf Tnodes jevp Latent_heat Humidity com_nod
global coeff3 coeff2 coeff1 coeff0 coeffA  coeffB rho Wetting_angle dx L1 H1

%INPUT DATA
%Problem parameters
under_relax = 0.3; %under relaxation parameter
coupled = 1;

if(coupled==1) 
errormax = 1e-4; %maximum error for convergence
end

if(coupled==0) 
errormax = 1e6; %maximum error for convergence
end 

% substarte: glass =0.9642, copper = 401.0
k_substrate = 401;

%Choose fluid  
% liquid = 1 for water,  
% liquid = 2 for IPA
% liquid = 3 for methaonol
% liquid 4 = for ethanol
% liquid 5 = for cholorform
% liquid 6 = for acetone

liquid = 1; 

%Thermophysical properties of water

if(liquid==1)
    rho = 1000;
    k_droplet = 0.61;   % thermal conductivity of the droplet (W/m-k)
    Latent_heat = 2263.5e3; %J/kg
    %Hu and Larson took 2263.5e3 J/kg for glass
    %Fitting coefficients for vapor concentration
    %c = p3*(T^3) +p2*(T^2) + p1*T +p0; T in degree Celcius and c in kg/m3
    %For water
    coeff3 = 9.9889e-07;
    coeff2 = -6.9437e-05;
    coeff1 = 3.2003e-3;
    coeff0 = -2.8736e-2;    
    % lower temperatures
    %coeff3 = 8.667e-07;
    %coeff2 = -4.449e-05;
    %coeff1 = 1.763e-3;
    %coeff0 = -4.587e-3;
   
    %Fitting coefficients of diffusion coefficient
    %D = coeffA*exp(-coeffB/T+273)  D in m^2/s and T in ^oC 
    coeffA = 2.5e-4;
    coeffB = 684.15;
end 

% %Thermophysical properties of isopropanol
if(liquid==2)
    k_droplet = 0.13;   % thermal conductivity of the droplet (W/m-k)
    Latent_heat = 768e3; %J/kg
    %Fitting coefficients for vapor concentration
    %c = p3*(T^3) +p2*(T^2) + p1*T +p0; T in degree Celcius and c in kg/m3
    coeff3  = 5.12e-6;
    coeff2 = -2.51e-4;
    coeff1 = 1.12e-2;
    coeff0 = -5.463e-2;
    %Fitting coefficients of diffusion coefficient
    %D = coeffA*exp(-coeffB/T+273)  D in m^2/s and T in ^oC 
    coeffA = 1.0e-4;
    coeffB = 690.0;
end 

% %Thermophysical properties of methanol
if(liquid==3)
    k_droplet = 0.2091;   % thermal conductivity of the droplet (W/m-k)
    Latent_heat = 1100.0e3; %J/kg
    %Hu and Larson took 2263.5e3 J/kg for glass
    %Fitting coefficients for vapor concentration
    %c = p3*(T^3) +p2*(T^2) + p1*T +p0; T in degree Celcius and c in kg/m3
    %For water
    coeff3  = 5.12e-6;
    coeff2 = -2.51e-4;
    coeff1 = 1.12e-2;
    coeff0 = -5.463e-2;
    %Fitting coefficients of diffusion coefficient
    %D = coeffA*exp(-coeffB/T+273)  D in m^2/s and T in ^oC 
    coeffA = 1.0e-4;
    coeffB = 690.0;
end 


% %Thermophysical properties of ethanol
if(liquid==4)
    k_droplet = 0.1643;   % thermal conductivity of the droplet (W/m-k)
    Latent_heat = 846.0e3; %J/kg
    %Hu and Larson took 2263.5e3 J/kg for glass
    %Fitting coefficients for vapor concentration
    %c = p3*(T^3) +p2*(T^2) + p1*T +p0; T in degree Celcius and c in kg/m3
    %For water
    coeff3  = 4.4092e-6;
    coeff2 = -1.6787e-4;
    coeff1 = 8.643e-3;
    coeff0 = -2.8922e-2;
    %Fitting coefficients of diffusion coefficient
    %D = coeffA*exp(-coeffB/T+273)  D in m^2/s and T in ^oC 
    coeffA = 1.0e-4;
    coeffB = 690.0;
end 


% %Thermophysical properties of cholorform
if(liquid==5)
    k_droplet = 0.1150;   % thermal conductivity of the droplet (W/m-k)
    Latent_heat = 247.0e3; %J/kg
    %Hu and Larson took 2263.5e3 J/kg for glass
    %Fitting coefficients for vapor concentration
    %c = p3*(T^3) +p2*(T^2) + p1*T +p0; T in degree Celcius and c in kg/m3
    %For water
    coeff3  = 8.0001e-6;
    coeff2  = 2.5723e-4;
    coeff1  = 2.3393e-2;
    coeff0  = 4.0275e-1;
    %Fitting coefficients of diffusion coefficient
    %D = coeffA*exp(-coeffB/T+273)  D in m^2/s and T in ^oC 
    coeffA = 1.0e-4;
    coeffB = 690.0;
end 

if(liquid==6)
    k_droplet = 0.18;   % thermal conductivity of the droplet (W/m-k)
    %Madzhidov Kh.: Thermal Conductivity of Ketones as a Function of Temperature. Inzh.Fiz.Zh. 47 (1984) 256-262
        Latent_heat = 552e3; %J/kg
    %Hu and Larson took 2263.5e3 J/kg for glass
    %Fitting coefficients for vapor concentration
    %c = p3*(T^3) +p2*(T^2) + p1*T +p0; T in degree Celcius and c in kg/m3
    %For water
    coeff3  = 5.12e-6;
    coeff2 = -2.51e-4;
    coeff1 = 1.12e-2;
    coeff0 = -5.463e-2;
    %Fitting coefficients of diffusion coefficient
    %D = coeffA*exp(-coeffB/T+273)  D in m^2/s and T in ^oC 
    coeffA = 1.0e-4;
    coeffB = 690.0;
end 

%mesh generation
[ p,e,t, pd,ed,td, pa, ea, ta,H2] = MESH( Wetting_angle, L2, L1, H1, n_cap,com_nod,dx);

np=size(p,2);       % total mesh points
k = 1:size(t,2);
x =   (p(1,t(1,k))  + p(1,t(2,k))  + p(1,t(3,k)))/3;

%Assign c vector for the droplet and substrate regions.
c =zeros(1,size(t,2));
for i = 1:size(t,2)
    if(t(4,i)==1)
        c(i) = k_substrate*x(i); %sub
    else
        c(i) = k_droplet*x(i); %droplet
    end
end


jevp = zeros(1, n_cap-1); %initialize
jevpOld = zeros(1, n_cap-1);
Temp_domainNew = zeros(np,1);
Temp_domainOld = (1.0e10)*ones(np,1);

while (norm(abs(Temp_domainOld- Temp_domainNew)) > errormax)
    
    Temp_domainOld = Temp_domainNew;
    u = assempde('BoundCondTemperature',p,e,t,c,0,0);
    Temp_domainNew = u;
    TfreeSurf(:,1:n_cap-1) = 0;
    xnode(:,1:n_cap) = 0;
    xedge(:,1:n_cap-1) = 0;

    count = 0;
    for k = 1:size(e,2)
         if (e(6,k) == 2 && e(7,k) == 0)
            count = count +1;
            Tnodes(:, count) =   u(e(1,k),1);
            TfreeSurf(:,count) = (u(e(1,k),1) + u(e(2,k),1))/2; % Take avg temp over an edge
            klastedge_freesurf = k;
            xedge(:, count) = ( p(1,e(1,k)) + p(1,e(2,k)) )*0.5 ;
            xnode(:, count) =  p(1,e(1,k));
         end
    end
    
    Tnodes(:, count+1) = u(e(2,klastedge_freesurf),1); 
    xnode(:, count+1) =  p(1,e(2,klastedge_freesurf)); 
    
    [flux_edge, flux_node, f, g, u1] = SolveDiffusion(pa, ea, ta);
    jevp = flux_edge;
    jevp = jevpOld*(1 - under_relax) + jevp*under_relax;
    jevpOld = jevp;
 
    
end % end of convergence loop 
error = norm(abs(Temp_domainOld- Temp_domainNew))

area=0;
jevap=0;
for i= 1:n_cap-1
    ds=sqrt((((p(1,i+3))-(p(1,i+4)))^2)+(((p(2,i+3))-(p(2,i+4)))^2));
    area = area + 2*pi*(xedge(i))*ds;
    jevap = jevap+2*pi*(xedge(i))*ds*flux_edge(i);
end

ana_area = 2*pi*r_drop*r_drop*(1-cos(Wetting_angle*pi/180))/((sin(Wetting_angle*pi/180))^2);

mass_evap = jevap;
    
%Make a tecplot compatible file for vapor concentration
fid = fopen('VaporConc.dat','w');
fprintf(fid,'TITLE = "Vapor concentration"\n ');
fprintf(fid,'VARIABLES = "X","Y","C","JX","JY"\n ');
fprintf(fid,'VARIABLES =  X Y C JX JY\n');
fprintf(fid,'ZONE N=%6.0f,E=%6.0f,F=FEPOINT, ET=TRIANGLE\n',size(pa,2),size(ta,2));
for i = 1:size(pa,2)
fprintf (fid,'%6.12f\t   %6.12f\t  %6.12f \t %6.12f \t  %6.12f\n', pa(1,i), pa(2,i),u1(i,1), f(i,1), g(i,1) );
end
for i = 1:size(ta,2)
fprintf(fid,'%6.0f\t  %6.0f \t %6.0f\n', ta(1,i), ta(2,i), ta(3,i) );
end
fclose(fid);

% %Make a tecplot compatible file for temperature field
fid = fopen('Isotherms.dat','w');
fprintf(fid,'TITLE = "Temp"\n ');
fprintf(fid,'VARIABLES = "X","Y","T"\n ');
fprintf(fid,'VARIABLES =  X Y T\n');
fprintf(fid,'ZONE N=%6.0f,E=%6.0f,F=FEPOINT, ET=TRIANGLE\n',size(p,2),size(t,2));
for i = 1:size(p,2)
fprintf (fid,'%6.12f\t   %6.12f\t  %6.12f\n', p(1,i), p(2,i), Temp_domainNew(i,1) );
end
for i = 1:size(t,2)
fprintf(fid,'%6.0f\t  %6.0f \t %6.0f\n', t(1,i), t(2,i), t(3,i) );
end
fclose(fid);

% Compare with Hu and Larson, 2002.
r =xnode./r_drop;
r(1)=0.999;
theta=Wetting_angle*pi/180;

diff = 2.61e-5;
Csat =0.0232;
diff1 = 2.61e-5;
Csat1 = 0.0232;
term=(0.27*theta^2+1.30)*(0.6381-0.2239*(theta-pi/4)^2);
%j0=diff*Csat*(1-Humidity)/r_drop;
j01=diff1*(Csat1 - Csat*Humidity)/r_drop;
mass_evap_HuL = pi*r_drop*diff*(1-Humidity)*Csat*(0.27*theta*theta + 1.30);


figure(1); clf;
plot(xnode./r_drop,flux_node,'-*'); %plot dimensional flux at nodes
hold on;
j = j01*term*((1-r.^2).^-(0.5-theta/pi));
plot(r,j,'k');  %plot analytical
title('Evaporative flux at the free surface')
xlabel('Dimensionless radial distance')
ylabel('Evaporative flux j [kg/m^2-s]')
legend('Two-way model','Hu & Larson');
end
