function [ p,e,t, pd,ed,td, p1, e1, t1,H2] = MESH( Wetting_angle, L2, L1, H1, n_cap,com_nod,dx)


H2 = L2*tan(Wetting_angle*pi/180.0/2); % Height of spherical cap
R = (H2^2 + L2^2)/(2*H2);
theta0 = asin(1- H2/R);
theta1 = pi/2 - theta0;
 
 
%%-------droplet and substrate meshing-----------------
n = n_cap+com_nod-1;    % Number of line segments on boundary of cap R2
R1 = zeros(2 + 2*n, 1);
R2 = zeros(2 + 2*n, 1);
R2(1,1) = 2;            % 2 for polygon
R2(2,1) = n;

for i = 0:com_nod-1
    R2(3+i,1) = i*L2/(com_nod-1);
    R2(3+n+i,1) = 0.0;
end
dtheta = theta1/(n_cap-1);

% -----interface data collection for ambient mesh-----
na=n_cap+3; % total nodes specified for ambient mesh
gda=zeros(2+2*na,1);
gda(1,1)=2;          % 2 for polygon
gda(2,1)= na;
%------------------------------------

for i = 1:n_cap-1
    theta = theta1 - i*dtheta;
    R2(2+com_nod+i,1) = R*sin(theta);
    R2(2+n+com_nod+i,1) = H2-R*(1-cos(theta));
    % -----interface data collection for ambient mesh-----
    gda(2+n_cap-i,1)= R*sin(theta);
    gda(2+na+n_cap-i,1)= H2-R*(1-cos(theta));
    %----------------------------------------------------
end


% dy=5;%0.03; %size of edge
% nn=floor(H1/dy)-1;    %defines number of nodes on right side boundary
n = 3+com_nod;      % Number of line segments on boundary of R1
R1(1,1) = 2;        % 2 for polygon
R1(2,1) = n;
R1(3:4,1) = [0,L1]';
%R1(3:5,1) = [0,L1,L1]';
R1(3+n:4+n,1) = [0,0]';
%R1(6+com_nod:6+com_nod+2,1) = [0,0,H1]';
% for i=1:nn      %putting nodes on right side boundary
%     R1(4+i,1)=L1;
%     R1(4+n+i,1)=dy*i;
% end

R1(4+1,1)=L1;
R1(4+n+1,1)=H1;

for i = 0:com_nod-1
    R1(6+i,1) = L2 - i*L2/(com_nod-1);
    R1(6+n+i,1) = H1;
end
%Translate geometry
R1(3+n:2*n+2,1) = R1(3+n:2*n+2,1) - H1; %for substrate

% create geometry
gd = [R1, R2];
ns = (char('R1','R2'))';
sf = 'R1+R2';
dl = decsg(gd,sf,ns);


%[p,e,t] = initmesh(dl,'Hgrad',1.1,'MesherVersion', 'R2013a');

%[p,e,t] = initmesh(dl,'Hmax',0.2,'Hgrad',1.1,'MesherVersion', 'R2013a');
[p,e,t] = initmesh(dl,'Hmax',dx,'Hgrad',1.3);

% create only drope mesh geometry
dl = decsg(R2);
%[pd,ed,td] = initmesh(dl,'Hmax',0.05,'Hgrad',1.3,'MesherVersion', 'R2013a');
[pd,ed,td] = initmesh(dl,'Hmax',dx,'Hgrad',1.3);


%%-------END of droplet and substrate meshing-----------------

%=====================ambient mesh====================================

MaxBoundx = 50.0; %e-3; % Bound on x-coordinate in far-field
MaxBoundy = 50.0; %e-3; % Bound on y-coordinate in far-field

gda(2+n_cap,1)=L2;
gda(2+na+n_cap,1)=0.0;

gda(2+n_cap+1,1)=MaxBoundx;
gda(2+na+n_cap+1,1)=0.0;

gda(2+n_cap+2,1)=MaxBoundx;
gda(2+na+n_cap+2,1)=MaxBoundy;

gda(2+n_cap+3,1)=0.0;
gda(2+na+n_cap+3,1)=MaxBoundy;

dl1 = decsg(gda);
%[p1, e1, t1] = initmesh(dl1,'Hmax',2,'Hgrad',1.2,'MesherVersion', 'R2013a'); % Create mesh
[p1, e1, t1] = initmesh(dl1,'Hmax',2,'Hgrad',1.3,'MesherVersion', 'R2013a'); % Create mesh


%=====================END of ambient mesh=============================

p=(1e-3)*p;
pd=(1e-3)*pd;
p1=(1e-3)*p1;


% % %Make a tecplot compatible file for temperature field
% fid = fopen('drop_subs.dat','w');
% fprintf(fid,'TITLE = "drop_sub"\n ');
% fprintf(fid,'VARIABLES = "X","Y"\n ');
% fprintf(fid,'VARIABLES =  X Y\n');
% fprintf(fid,'ZONE N=%6.0f,E=%6.0f,F=FEPOINT, ET=TRIANGLE\n',size(p,2),size(t,2));
% for i = 1:size(p,2)
% fprintf (fid,'%6.12f\t %6.12f\n', p(1,i), p(2,i));
% end
% for i = 1:size(t,2)
% fprintf(fid,'%6.0f\t  %6.0f \t %6.0f\n', t(1,i), t(2,i), t(3,i) );
% end
% fclose(fid);
% 
% % %Make a tecplot compatible file for temperature field
% fid = fopen('drop.dat','w');
% fprintf(fid,'TITLE = "drop_sub"\n ');
% fprintf(fid,'VARIABLES = "X","Y"\n ');
% fprintf(fid,'VARIABLES =  X Y\n');
% fprintf(fid,'ZONE N=%6.0f,E=%6.0f,F=FEPOINT, ET=TRIANGLE\n',size(pd,2),size(td,2));
% for i = 1:size(pd,2)
% fprintf (fid,'%6.12f\t %6.12f\n', pd(1,i), pd(2,i));
% end
% for i = 1:size(td,2)
% fprintf(fid,'%6.0f\t  %6.0f \t %6.0f\n', td(1,i), td(2,i), td(3,i) );
% end
% fclose(fid);
% 
% % %Make a tecplot compatible file for temperature field
% fid = fopen('ambient.dat','w');
% fprintf(fid,'TITLE = "drop_sub"\n ');
% fprintf(fid,'VARIABLES = "X","Y"\n ');
% fprintf(fid,'VARIABLES =  X Y\n');
% fprintf(fid,'ZONE N=%6.0f,E=%6.0f,F=FEPOINT, ET=TRIANGLE\n',size(p1,2),size(t1,2));
% for i = 1:size(p1,2)
% fprintf (fid,'%6.12f\t %6.12f\n', p1(1,i), p1(2,i));
% end
% for i = 1:size(t1,2)
% fprintf(fid,'%6.0f\t  %6.0f \t %6.0f\n', t1(1,i), t1(2,i), t1(3,i) );
% end
% fclose(fid);




end

