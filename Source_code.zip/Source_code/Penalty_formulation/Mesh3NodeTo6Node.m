function [ p1, e1, t1 ] = Mesh3NodeTo6Node( p,e,t )
p1=p;
t1=t;

% d matrix stores the id of old nodes and new node of each line segment of mesh 
d=zeros(1,3);
d_size=1;
pn=size(p,2);


flag1=0;
flag2=0;
flag3=0;
dn=0;

for i=1:size(t,2)
    
    n1=t(1,i);
    n2=t(2,i);
    n3=t(3,i);
    
    x1= p(1,t(1,i));
    x2= p(1,t(2,i));
    x3= p(1,t(3,i));
    
    y1= p(2,t(1,i));
    y2= p(2,t(2,i));
    y3= p(2,t(3,i));
    
    x4= (x1+x2)/2;
    x5= (x2+x3)/2;
    x6= (x3+x1)/2;
    
    y4= (y1+y2)/2;
    y5= (y2+y3)/2;
    y6= (y3+y1)/2;
    
    for j=1:d_size
        if (n1== d(j,1) && n2==d(j,2))||(n1== d(j,2) && n2==d(j,1))
            pn4=d(j,3);
            flag1=1;
        end
    end
    
    if flag1==0
        pn=pn+1;
        pn4=pn;
        p1(1,pn4)=x4;
        p1(2,pn4)=y4;
        
        dn=dn+1;
        d(dn,1)=t(1,i);
        d(dn,2)=t(2,i);
        d(dn,3)=pn4;
    end
    
    
    for j=1:d_size
        if (n2== d(j,1) && n3==d(j,2))||(n2== d(j,2) && n3==d(j,1))
            pn5=d(j,3);
            flag2=1;
        end
    end
    if flag2==0
        pn=pn+1;
        pn5=pn;
        p1(1,pn5)=x5;
        p1(2,pn5)=y5;
        
        dn=dn+1;
        d(dn,1)=t(2,i);
        d(dn,2)=t(3,i);
        d(dn,3)=pn5;
    end
    
    
    for j=1:d_size
        if (n3== d(j,1) && n1==d(j,2))||(n3== d(j,2) && n1==d(j,1))
            pn6=d(j,3);
            flag3=1;
        end
    end
    if flag3==0
        pn=pn+1;
        pn6=pn;
        p1(1,pn6)=x6;
        p1(2,pn6)=y6;
        
        dn=dn+1;
        d(dn,1)=t(3,i);
        d(dn,2)=t(1,i);
        d(dn,3)=pn6;
    end
    
    flag1=0;
    flag3=0;
    flag2=0;
    
    
    %t1(2,i)=t(2,i);
    %t1(3,i)=t(3,i);
    t1(4,i)=pn4;
    t1(5,i)=pn5;
    t1(6,i)=pn6;
    
    d_size= size(d,1);
end

e1=zeros(8,size(e,2));
e1(1,:)=e(1,:);
e1(3:8,:)=e(2:7,:);
for i=1:size(e,2)
    n1=e(1,i);
    n2=e(2,i);
    
    for j=1:d_size
        if (n1== d(j,1) && n2==d(j,2))
           e1(2,i)=d(j,3);
        end
    end
end

fid = fopen('sixnodemesh.dat','w');
fprintf(fid,'TITLE = "mesh"\n ');
fprintf(fid,'VARIABLES =  X Y\n');
fprintf(fid,'ZONE N=%6.0f,E=%6.0f,F=FEPOINT, ET=TRIANGLE\n',size(p,2),size(t,2));
for i = 1:size(p,2)
    fprintf (fid,'%20.12e\t %20.12e\n', p(1,i), p(2,i));
end
for i = 1:size(t,2)
    fprintf(fid,'%6.0f\t  %6.0f \t %6.0f\n', t(1,i), t(2,i), t(3,i) );
end
fclose(fid);


fid = fopen('allnodes.dat','w');
fprintf(fid,'VARIABLES =  X Y\n');
for i = 1:size(p1,2)
    fprintf (fid,'%20.12e\t %20.12e\n', p1(1,i), p1(2,i));
end
fclose(fid);
end

