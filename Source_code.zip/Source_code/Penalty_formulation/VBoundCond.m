function [ sa, sf ] = VBoundCond( sa, sf, e, p,unet, n_cap,nrr,nzz)

num=2*size(p,2);
for i=1:size(e,2)
    
%     %free surafce boundary condition
%     if e(6,i) < n_cap
%         iv1 = 2*e(1,i);
%         iv2 = 2*e(2,i);
%         iu1 = 2*e(1,i)-1;
%         iu2 = 2*e(2,i)-1;
%         
%         suu = sa(iu1,iu1);
%         suv = sa(iu1,iv1);
%         svu = sa(iv1,iu1);
%         svv = sa(iv1,iv1);
%         nr = nrr(e(1,i));
%         nz = nzz(e(1,i));
%         u1  = unet(e(1,i))*nr;
%         v1  = unet(e(1,i))*nz;
%         
%         sa(iv1,iu1) =  nz*nr*suu + nz*nz*svu - nr*nr*suv - nr*nz*svv;
%         sa(iv1,iv1) =  nr*nr*suu + nr*nz*svu + nr*nz*suv + nz*nz*svv;
%         sf(iv1,1) =  u1*nr + v1*nz;
%         
%         suu = sa(iu2,iu2);
%         suv = sa(iu2,iv2);
%         svu = sa(iv2,iu2);
%         svv = sa(iv2,iv2);
%         nr = 0.5*(nrr(e(1,i))+ nrr(e(3,i)));
%         nz = 0.5*(nzz(e(1,i))+ nzz(e(3,i)));
%         u2  = 0.5*(unet(e(1,i))+unet(e(3,i)))*nr;
%         v2  = 0.5*(unet(e(1,i))+unet(e(3,i)))*nz;
%         
%         sa(iv2,iu2) = nz*nr*suu + nz*nz*svu - nr*nr*suv - nr*nz*svv;
%         sa(iv2,iv2) = nr*nr*suu + nr*nz*svu + nr*nz*suv + nz*nz*svv;
%         
%         
%         sf(iv2,1) = u2*nr + v2*nz;
%         
%     end
    
%         %axisymmetric boundary condition
%          if e(6,i)== n_cap
%             iu1 = 2*e(1,i)-1;
%             iu2 = 2*e(2,i)-1;
%             u  = uz(n_cap);
%     
%             for ju = 1:num;
%                 sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
%                 sa(iu1,ju) = 0.0;
%                 sa(ju,iu1) = 0.0;
%     
%                 sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u;
%                 sa(iu2,ju) = 0.0;
%                 sa(ju,iu2) = 0.0;
%             end
%     
%             sa(iu1,iu1) = 1.0;
%             sf(iu1,1)    = u;
%             sa(iu2,iu2) = 1.0;
%             sf(iu2,1)    = u;
%     
%         end
    
    %bottom boundary condition
    if e(6,i)> n_cap
        iu1 = 2*e(1,i);
        iu2 = 2*e(2,i);
        u  = 0.0;
        
        for ju = 1:num;
            sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
            sa(iu1,ju) = 0.0;
            sa(ju,iu1) = 0.0;
            
            sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u;
            sa(iu2,ju) = 0.0;
            sa(ju,iu2) = 0.0;
        end
        
        sa(iu1,iu1) = 1.0;
        sf(iu1,1)    = u;
        sa(iu2,iu2) = 1.0;
        sf(iu2,1)    = u;
        
    end
    
    
end

% %-------droplet top node boundary condition------------
% iv1 = 2*n_cap;
% iu1 = 2*n_cap-1;
% 
% suu = sa(iu1,iu1);
% suv = sa(iu1,iv1);
% svu = sa(iv1,iu1);
% svv = sa(iv1,iv1);
% nr = nrr(n_cap);
% nz = nzz(n_cap);
% u1  = unet(n_cap)*nr;
% v1  = unet(n_cap)*nz;
% 
% sa(iv1,iu1) = nz*nr*suu + nz*nz*svu - nr*nr*suv - nr*nz*svv;
% sa(iv1,iv1) = nr*nr*suu + nr*nz*svu + nr*nz*suv + nz*nz*svv;
% sf(iv1,1) = u1*nr + v1*nz;
end

