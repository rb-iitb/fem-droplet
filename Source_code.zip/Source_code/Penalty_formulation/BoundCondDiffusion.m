function [q,g,h,r] = BoundCondDiffusion(p,e,u,time)
% This function creates the boundary condition
% m file for the use in function  ASSEMB or
% assempde. To know the format of boundary condition
% see the example given on Mathworks website
% under the function  ASSEMB

global TfreeSurf Tnodes n_cap Humidity T_ambient coeff3 coeff2 coeff1 coeff0

RhoAmbient = coeff3*(T_ambient^3) + coeff2*(T_ambient^2) + coeff1*T_ambient + coeff0;
%RhoAmbient =0.0232;
RhoFarField = Humidity*RhoAmbient;  %vapor concentration in far-field
FreeSurfNodes = n_cap;
RhoFreeSurf(:,1:FreeSurfNodes-1) = 0;
for i = 1:1:FreeSurfNodes-1
    T = TfreeSurf(1,i);
    RhoFreeSurf(:,FreeSurfNodes-i) =  coeff3.*(T^3) + coeff2.*(T^2) + coeff1.*T + coeff0;
    %RhoFreeSurf(:,FreeSurfNodes-i) = 0.0232;
end

ne = size(e,2);  %Total number of edges
q = zeros(1,ne);
g = zeros(1,ne);
h = zeros(1,2*ne);
r = zeros(1,2*ne);

for k=1:ne  % for each edge
    % extract info about current edge
    edge = e(:,k);
    % get boundary section of this edge
    edge_label = edge(5);
    % If this edge is a Dirichlet BC, extract
    % appropriate values of h and r.
    %if(edge_label == 1||edge_label == 2)  % if Dirichlet BC
    if(edge_label == FreeSurfNodes+1||edge_label == FreeSurfNodes+2)  % if Dirichlet BC
        
        % find BC parameters for this edge
        h(:,k) = 1.0;
        r(:,k)  = RhoFarField;
        h(:,ne+k) = 1.0;
        r(:,ne+k) = RhoFarField;
        % record once in column k of he for value
        % of BCs at start of the edge
        % record again in column ne+k for value of
        % BCs at end of the edge. Recording these twice
        % allow us to use variation in BC value
        % over the edge if we wish (See ASSEMB for more info).
    elseif  (edge_label == FreeSurfNodes||edge_label == FreeSurfNodes+3)% else if it is a Neuman BC
        h(:,k) = 0.0;
        r(:,k)  = 0.0;
        h(:,ne+k) =0.0;
        r(:,ne+k) = 0.0;
    else
        h(:,k) = 1.0;
        r(:,k)  = RhoFreeSurf(:,edge_label);
        h(:,ne+k) = 1.0;
        r(:,ne+k) = RhoFreeSurf(:,edge_label);
    end
end


return;