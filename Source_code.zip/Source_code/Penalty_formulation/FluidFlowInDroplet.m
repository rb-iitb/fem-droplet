%**************************************************************************
% =======2D-axisymmetric steady state FEM solver is developed by ==========
% =============== Manish Kumar, Ph.D. Scholar, IIT Bombay==================
% =================== Email: manishk.iitb@gmail.com =======================
% It solves the coupled physics of energy, momentum and mass transport during droplet evporation
% Energy transport equation without advection terms is solved for droplet and substrate domain
% Mass transport (Vapor concentration) equation is solved in droplet ambient
% Momentum transport equations are solved in droplet domain using
% -------------------Panalty funcition formulation-------------------------
% *************************************************************************

clc; clear all;
tic
%Define global parameters
global L2 H2 n_cap Humidity T_ambient com_nod
global T_substrate rho Wetting_angle dx L1 H1

%**************************INPUT DATA**************************************
%Parameters
L2 = 1;                         %Droplet wetted radius in mm
Wetting_angle = 40.0;           %in degress
T_ambient = 25;                 %degree Celcius
T_substrate = 25;               %degree Celcius
Humidity = 0.35;

% Droplet liquid viscosity
 mu_liq= 8.9e-4; %Pa.s

% droplet mesh control
dx=0.03;
n_cap = 200;     % number of node on free surface


%Substrate size control
L1 = 5.0; % width of subtrate 
H1 = 0.1; % thickness of substrate

%**************************************************************************

WetAngRad=Wetting_angle*pi/180;
r_drop=L2*0.001; %Wetted radius in m
gm=mu_liq*1e10; %penalty parameter
com_nod = 5;   % number of common grid points

%******Solving evaporation flux (flux_node) using Two-way model***********
[xnode,flux_node,mass_evap,p,e,t] = MainCode(r_drop);

%******Calculating net velocity at the liquid-gas interface of the droplet
[unet,nr,nz] = Unet_interface(xnode,flux_node,mass_evap,H2,r_drop,rho,WetAngRad);


%creating 6 noded mesh of droplet domain
[ p1, e1, t1 ] = Mesh3NodeTo6Node( p,e,t );
figure(2);clf;
pdemesh(p,e,t);
hold on;
plot(p1(1,:),p1(2,:),'.r','MarkerSize',10);
xlabel('r (m)') % x-axis label
ylabel('z (m)') % y-axis label
%--------------------Mesh generation done--------------------------
[  MMM, MMMb, Sai, dSz, dSn, fdSz, fdSn,w,fw,odSz,odSn ] = NumIntCoeff;


%==============================In house solver=============================
num_nodes=size(p1,2);
num_elts=size(t1,2);

ppe=zeros(1,num_elts);
sa=zeros(2*num_nodes,2*num_nodes);
sf=zeros(2*num_nodes,1);

for k=1:num_elts
    
    b1  = p(2,t(2,k)) - p(2,t(3,k));
    b2  = p(2,t(3,k)) - p(2,t(1,k));
    c1  = p(1,t(3,k)) - p(1,t(2,k));
    c2  = p(1,t(1,k)) - p(1,t(3,k));
    area  = (b1*c2-b2*c1)/2.0;
    rav   = (p(1,t(1,k))+p(1,t(2,k))+p(1,t(3,k)))/3.0;
    
    k1    = rav/area/4.0;
    MM   = 2.*area.*MMM;
    MMb  = 2.*area.*MMMb;
    
    for i = 1:6
        ii = (t1(i,k));
        iu = 2*ii-1;
        iv = 2*ii;
        
        for  j = 1:6
            jj  = (t1(j,k));
            ju  = jj*2-1;
            jv  = jj*2;
            
            Srr=0; Srrb=0;  Sr0b=0;
            Srz=0; Srzb=0;  Sz0b=0;
            Szr=0; Szrb=0;  Sr0bt=0;
            Szz=0; Szzb=0;  Sz0bt=0;
            for kk =1:3
                Srr = Srr + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                Srz = Srz + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                Szr = Szr + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                Szz = Szz + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
            end
            
            for kk =1:1
                Srrb = Srrb + k1*fw(kk)*(b1*fdSz(i,kk)+b2*fdSn(i,kk))*(b1*fdSz(j,kk)+b2*fdSn(j,kk));
                Srzb = Srzb + k1*fw(kk)*(b1*fdSz(i,kk)+b2*fdSn(i,kk))*(c1*fdSz(j,kk)+c2*fdSn(j,kk));
                Szrb = Szrb + k1*fw(kk)*(c1*fdSz(i,kk)+c2*fdSn(i,kk))*(b1*fdSz(j,kk)+b2*fdSn(j,kk));
                Szzb = Szzb + k1*fw(kk)*(c1*fdSz(i,kk)+c2*fdSn(i,kk))*(c1*fdSz(j,kk)+c2*fdSn(j,kk));
                Sr0b = Sr0b + 0.5*fw(kk)*(b1*fdSz(i,kk)+b2*fdSn(i,kk))*Sai(j);
                Sz0b = Sz0b + 0.5*fw(kk)*(c1*fdSz(j,kk)+c2*fdSn(j,kk))*Sai(i);
                Sr0bt = Sr0bt + 0.5*fw(kk)*(b1*fdSz(j,kk)+b2*fdSn(j,kk))*Sai(i);
                Sz0bt = Sz0bt + 0.5*fw(kk)*(c1*fdSz(i,kk)+c2*fdSn(i,kk))*Sai(j);
            end
            M   = MM(i,j);
            Mb  = MMb(i,j);
            Krr = 2*mu_liq*Srr + mu_liq*Szz + (2*mu_liq*M/rav) + gm*Srrb  + gm*(Sr0b+Sr0bt+(Mb/rav));
            Krz = mu_liq*Szr + gm*Srzb + gm*Sz0b;
            Kzr = mu_liq*Srz + gm*Szrb + gm*Sz0bt;
            Kzz = mu_liq*Srr + 2*mu_liq*Szz + gm*Szzb;
            
  
            sa(iu,ju) = sa(iu,ju) + Krr;
            sa(iu,jv) = sa(iu,jv) + Krz;
   
            sa(iv,ju) = sa(iv,ju) + Kzr;
            sa(iv,jv) = sa(iv,jv) + Kzz;
        end
    end
end

[ sa, sf,qt ] = UBoundCond( sa, sf, e1, p1,unet, n_cap,nr,nz);
[ sa, sf ] = VBoundCond( sa, sf, e1, p1,unet, n_cap,nr,nz);


uv = sa\sf;

uv=qt*uv;

i=1:num_nodes;
uun = uv(2*i-1,1);
vvn = uv(2*i,1);

for k=1:num_elts
    
    b1  = p(2,t(2,k)) - p(2,t(3,k));
    b2  = p(2,t(3,k)) - p(2,t(1,k));
    c1  = p(1,t(3,k)) - p(1,t(2,k));
    c2  = p(1,t(1,k)) - p(1,t(3,k));
    
    rav   = (p(1,t(1,k))+p(1,t(2,k))+p(1,t(3,k)))/3.0;
    area  = (b1*c2-b2*c1)/2.0;
    k2    = 1.0/area/2.0;
    
    pp=0;
    for i = 1:6
        ii = (t1(i,k));
        pp = pp + k2*(b1*odSz(i)+b2*odSn(i))*uun(ii,1) + k2*(c1*odSz(i)+c2*odSn(i))*vvn(ii,1) + uun(ii,1)*Sai(i)/rav;
    end
    
    ppe(1,k)= -1*gm*pp;
end

ppn=pdeprtni(p,t,ppe);

fid = fopen('UPV_data.dat','w');
fprintf(fid,'TITLE = "mesh"\n ');
fprintf(fid,'VARIABLES =  X Y P V U\n');
fprintf(fid,'ZONE N=%6.0f,E=%6.0f,F=FEPOINT, ET=TRIANGLE\n',size(p,2),size(t,2));
for i = 1:size(p,2)
    fprintf (fid,'%20.12e\t %20.12e\t %20.12e\t %20.12e\t %20.12e\n', 1000*p(1,i), 1000*p(2,i), ppn(i,1) , 1000*vvn(i,1), 1000*uun(i,1));
end
for i = 1:size(t,2)
    fprintf(fid,'%6.0f\t  %6.0f \t %6.0f\n', t(1,i), t(2,i), t(3,i) );
end
fclose(fid);
 

figure(3);clf;
pdeplot(p,e,t,'xydata',uun(1:size(p,2),1),'contour','on','levels',20);
hold on;
title('Radial velocity (u)')
xlabel('r (m)') % x-axis label
ylabel('z (m)') % y-axis label
c = colorbar;
c.Label.String = '(m/s)';

figure(4);clf;
pdeplot(p,e,t,'xydata',vvn(1:size(p,2),1),'contour','on','levels',20);
hold on;
title('Axial velocity (v)')
xlabel('r (m)') % x-axis label
ylabel('z (m)') % y-axis label
c = colorbar;
c.Label.String = '(m/s)';


figure(5);clf;
pdeplot(p,e,t,'xydata',ppn(1:size(p,2),1),'contour','on','levels',20);
hold on;
title('Pressure (P)')
xlabel('r (m)') % x-axis label
ylabel('z (m)') % y-axis label
c = colorbar;
c.Label.String = '(N/m^2)';


%plotting comparison with Hu and Larson
CompHuL(p1,uun,WetAngRad,r_drop);


fprintf('done\n');
toc