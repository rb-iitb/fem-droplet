function [ sa, sf ] = VBoundCond( sa, sf, e, p,unet, n_cap,inum_nodes,nr,nz)

num=2*size(p,2)+inum_nodes;
for i=1:size(e,2)
    
%     %free surafce boundary condition
%     if e(6,i) < n_cap
%         iv1 = 3*e(1,i)-1;
%         iv2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes);
%         iu1 = 3*e(1,i)-2;
%         iu2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes)-1;
%         nz2  = 0.5*(nz(e(1,i))+ nz(e(3,i)));
%         nr2  = 0.5*(nr(e(1,i))+ nr(e(3,i)));
%         v1  = gm2*unet(e(1,i))*nz(e(1,i));
%         v2  = gm2*0.5*(unet(e(1,i))+unet(e(3,i)))*nz2;
%         
%         sa(iv1,iu1) = sa(iv1,iu1) + gm2*nr(e(1,i))*nz(e(1,i));
%         sa(iv1,iv1) = sa(iv1,iv1) + gm2*nz(e(1,i))*nz(e(1,i));
%         
%         sa(iv2,iu2) = sa(iv2,iu2) + gm2*nr2*nz2;
%         sa(iv2,iv2) = sa(iv2,iv2) + gm2*nz2*nz2;
%         
%         sf(iv1,1) = sf(iv1,1) + v1;
%         sf(iv2,1) = sf(iv2,1) + v2;
%     end
%     
%         %axisymmetric boundary condition
%          if e(6,i)== n_cap
%             iu1 = 2*e(1,i)-1;
%             iu2 = 2*e(2,i)-1;
%             u  = uz(n_cap);
%     
%             for ju = 1:num;
%                 sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
%                 sa(iu1,ju) = 0.0;
%                 sa(ju,iu1) = 0.0;
%     
%                 sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u;
%                 sa(iu2,ju) = 0.0;
%                 sa(ju,iu2) = 0.0;
%             end
%     
%             sa(iu1,iu1) = 1.0;
%             sf(iu1,1)    = u;
%             sa(iu2,iu2) = 1.0;
%             sf(iu2,1)    = u;
%     
%         end
    
    %bottom boundary condition
    if e(6,i)> n_cap
        iu1 = 3*e(1,i)-1;
        iu2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes);
        u  = 0.0;
        
        for ju = 1:num;
            sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
            sa(iu1,ju) = 0.0;
            sa(ju,iu1) = 0.0;
            
            sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u;
            sa(iu2,ju) = 0.0;
            sa(ju,iu2) = 0.0;
        end
        
        sa(iu1,iu1) = 1.0;
        sf(iu1,1)    = u;
        sa(iu2,iu2) = 1.0;
        sf(iu2,1)    = u;
        
    end
    
    
end

% %-------droplet top node boundary condition------------
% iv1 = 3*n_cap-1;
% iu1 = 3*n_cap-2;
% u  = gm2*unet(n_cap)*nz(n_cap);
% 
% sa(iv1,iu1) = sa(iv1,iu1) + gm2*nr(n_cap)*nz(n_cap);
% sa(iv1,iv1) = sa(iv1,iv1) + gm2*nz(n_cap)*nz(n_cap);
% sf(iv1,1) = sf(iv1,1) + u;

end

