function [ sa, sf ] = PBoundCond( sa, sf,p,n_cap,inum_nodes)

num=2*size(p,2)+inum_nodes;
iu1 = 3*(n_cap);
u  = 0.0;

for ju = 1:num;
    sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
    sa(iu1,ju) = 0.0;
    sa(ju,iu1) = 0.0;
end

sa(iu1,iu1) = 1.0;
sf(iu1,1)    = u;
end

