%**************************************************************************
% =======2D-axisymmetric steady state FEM solver is developed by ==========
% =============== Manish Kumar, Ph.D. Scholar, IIT Bombay==================
% =================== Email: manishk.iitb@gmail.com =======================
% It solves the coupled physics of energy, momentum and mass transport during droplet evporation
% Energy transport equation without advection terms is solved for droplet and substrate domain
% Mass transport (Vapor concentration) equation is solved in droplet ambient
% Momentum transport equations are solved in droplet domain using
% -------------------Velocity-Pressure formulation-------------------------
% *************************************************************************
clc; clear all;
tic
%Define global parameters
%Define global parameters
global L2 H2 n_cap Humidity T_ambient com_nod
global T_substrate rho Wetting_angle dx L1 H1

%**************************INPUT DATA**************************************
%Parameters
L2 = 1;                         %Droplet wetted radius in mm
Wetting_angle = 40.0;           %in degress
T_ambient = 25;                 %degree Celcius
T_substrate = 25;               %degree Celcius
Humidity = 0.35;

% Droplet liquid viscosity
 mu_liq= 8.9e-4; %Pa.s

% droplet mesh control
dx=0.03;
n_cap = 200;     % number of node on free surface


%Substrate size control
L1 = 5.0; % width of subtrate 
H1 = 0.1; % thickness of substrate

%**************************************************************************



WetAngRad=Wetting_angle*pi/180;
r_drop=L2*0.001; %Wetted radius in m
com_nod = 5;   % number of common grid points

%******Solving evaporation flux (flux_node) using Two-way model***********
[xnode,flux_node,mass_evap,p,e,t] = MainCode(r_drop);


%******Calculating net velocity at the liquid-gas interface of the droplet
[unet,nr,nz] = Unet_interface(xnode,flux_node,mass_evap,H2,r_drop,rho,WetAngRad);


%creating 6 noded mesh of droplet domain
inum_nodes = size(p,2);
[ p1, e1, t1 ] = Mesh3NodeTo6Node( p,e,t );
figure(2);clf;
pdemesh(p,e,t);
hold on;
plot(p1(1,:),p1(2,:),'.r','MarkerSize',10);
%--------------------Mesh generation done--------------------------
[ MMM, dSz, dSn,w,phi,SSSphi,phiSSS ] = NumIntCoeff;


%==============================In house solver=============================
num_nodes=size(p1,2);
num_elts=size(t1,2);


sa=zeros(2*num_nodes+inum_nodes,2*num_nodes+inum_nodes);
sf=zeros(2*num_nodes+inum_nodes,1);

for k=1:num_elts
    
    b1  = p(2,t(2,k)) - p(2,t(3,k));
    b2  = p(2,t(3,k)) - p(2,t(1,k));
    c1  = p(1,t(3,k)) - p(1,t(2,k));
    c2  = p(1,t(1,k)) - p(1,t(3,k));
    area  = (b1*c2-b2*c1)/2.0;
    rav   = (p(1,t(1,k)) + p(1,t(2,k)) + p(1,t(3,k)))/3.0;
    k1    = rav/area/4.0;
    MM   = 2.0.*area.*MMM;
    SSphi= 2.0.*area.*SSSphi;
    phiSS= 2.0.*area.*phiSSS;
    
    for i = 1:6
        if i<=3
            ii = (t1(i,k));
            iu = 3*ii-2;
            iv = 3*ii-1;
            ip = 3*ii;
            
            for  j = 1:6
                if j<=3
                    jj  = (t1(j,k));
                    ju  = 3*jj-2;
                    jv  = 3*jj-1;
                    jp  = 3*jj;
                    
                    Srr=0; Sr0=0; Sr0t=0; %Srrb=0;
                    Srz=0; %Srzb=0;
                    Szr=0; %Szrb=0;
                    Szz=0; Sz0=0; Sz0t=0; %Szzb=0;
                    for kk =1:7
                        Srr = Srr + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                        Srz = Srz + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                        Szr = Szr + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                        Szz = Szz + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                        
                        Sr0 = Sr0 + 0.5*rav*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*phi(j,kk);
                        Sz0 = Sz0 + 0.5*rav*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*phi(j,kk);
                        
                        Sr0t = Sr0t + 0.5*rav*w(kk)*(b1*dSz(j,kk)+b2*dSn(j,kk))*phi(i,kk);
                        Sz0t = Sz0t + 0.5*rav*w(kk)*(c1*dSz(j,kk)+c2*dSn(j,kk))*phi(i,kk);
                    end
                    M   = MM(i,j);
                    Sphi=SSphi(i,j);
                    phiS=phiSS(i,j);
                    
                    sa(iu,ju) = sa(iu,ju) + 2*mu_liq*Srr + mu_liq*Szz + (2*mu_liq*M/rav);
                    sa(iu,jv) = sa(iu,jv) + mu_liq*Szr;
                    sa(iu,jp) = sa(iu,jp) + (-1)*Sr0 + (-1)*Sphi;
                    
                    sa(iv,ju) = sa(iv,ju) + mu_liq*Srz;
                    sa(iv,jv) = sa(iv,jv) + mu_liq*Srr + 2*mu_liq*Szz;
                    sa(iv,jp) = sa(iv,jp) + (-1)*Sz0;

                    sa(ip,ju) = sa(ip,ju) + (-1)*Sr0t + (-1)*phiS;
                    sa(ip,jv) = sa(ip,jv) + (-1)*Sz0t;
                    sa(ip,jp) = sa(ip,jp) + 0.0;

                else
                    jj  = (t1(j,k));
                    ju  = 3*inum_nodes + 2*(jj-inum_nodes)-1;
                    jv  = 3*inum_nodes + 2*(jj-inum_nodes);
                    
                    Srr=0; Sr0=0; Sr0t=0; %Srrb=0;
                    Srz=0; %Srzb=0;
                    Szr=0; %Szrb=0;
                    Szz=0; Sz0=0; Sz0t=0; %Szzb=0;
                    for kk =1:7
                        Srr = Srr + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                        Srz = Srz + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                        Szr = Szr + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                        Szz = Szz + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                        
                        Sr0t = Sr0t + 0.5*rav*w(kk)*(b1*dSz(j,kk)+b2*dSn(j,kk))*phi(i,kk);
                        Sz0t = Sz0t + 0.5*rav*w(kk)*(c1*dSz(j,kk)+c2*dSn(j,kk))*phi(i,kk);
                    end
                    M   = MM(i,j);
                    phiS=phiSS(i,j);
                    
                    sa(iu,ju) = sa(iu,ju) + 2*mu_liq*Srr + mu_liq*Szz + (2*mu_liq*M/rav);
                    sa(iu,jv) = sa(iu,jv) + mu_liq*Szr;
                    
                    sa(iv,ju) = sa(iv,ju) + mu_liq*Srz;
                    sa(iv,jv) = sa(iv,jv) + mu_liq*Srr + 2*mu_liq*Szz;
                    
                    sa(ip,ju) = sa(ip,ju) + (-1)*Sr0t + (-1)*phiS;
                    sa(ip,jv) = sa(ip,jv) + (-1)*Sz0t;
                    
                end
            end
        else
            ii = (t1(i,k));
            iu = 3*inum_nodes + 2*(ii-inum_nodes)-1;
            iv = 3*inum_nodes + 2*(ii-inum_nodes);
            
            for  j = 1:6
                if j<=3
                    jj  = (t1(j,k));
                    ju  = 3*jj-2;
                    jv  = 3*jj-1;
                    jp  = 3*jj;
                    
                    Srr=0; Sr0=0; Sr0t=0; %Srrb=0;
                    Srz=0; %Srzb=0;
                    Szr=0; %Szrb=0;
                    Szz=0; Sz0=0; Sz0t=0; %Szzb=0;
                    for kk =1:7
                        Srr = Srr + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                        Srz = Srz + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                        Szr = Szr + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                        Szz = Szz + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                        
                        Sr0 = Sr0 + 0.5*rav*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*phi(j,kk);
                        Sz0 = Sz0 + 0.5*rav*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*phi(j,kk);
                    end
                    M   = MM(i,j);
                    Sphi=SSphi(i,j);
                    
                    sa(iu,ju) = sa(iu,ju) + 2*mu_liq*Srr + mu_liq*Szz + (2*mu_liq*M/rav);
                    sa(iu,jv) = sa(iu,jv) + mu_liq*Szr;
                    sa(iu,jp) = sa(iu,jp) + (-1)*Sr0 + (-1)*Sphi;
                    
                    sa(iv,ju) = sa(iv,ju) + mu_liq*Srz;
                    sa(iv,jv) = sa(iv,jv) + mu_liq*Srr + 2*mu_liq*Szz;
                    sa(iv,jp) = sa(iv,jp) + (-1)*Sz0;
                   
                else
                    jj  = (t1(j,k));
                    ju  = 3*inum_nodes + 2*(jj-inum_nodes)-1;
                    jv  = 3*inum_nodes + 2*(jj-inum_nodes);
                    
                    Srr=0; Sr0=0; Sr0t=0; %Srrb=0;
                    Srz=0; %Srzb=0;
                    Szr=0; %Szrb=0;
                    Szz=0; Sz0=0; Sz0t=0; %Szzb=0;
                    for kk =1:7
                        Srr = Srr + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                        Srz = Srz + k1*w(kk)*(b1*dSz(i,kk)+b2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                        Szr = Szr + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(b1*dSz(j,kk)+b2*dSn(j,kk));
                        Szz = Szz + k1*w(kk)*(c1*dSz(i,kk)+c2*dSn(i,kk))*(c1*dSz(j,kk)+c2*dSn(j,kk));
                    end
                    M   = MM(i,j);
                    
                    sa(iu,ju) = sa(iu,ju) + 2*mu_liq*Srr + mu_liq*Szz + (2*mu_liq*M/rav);
                    sa(iu,jv) = sa(iu,jv) + mu_liq*Szr;
                    sa(iv,ju) = sa(iv,ju) + mu_liq*Srz;
                    sa(iv,jv) = sa(iv,jv) + mu_liq*Srr + 2*mu_liq*Szz;
                    
                end
            end
            
            
        end
    end
end
[ sa, sf, qt ] = UBoundCond( sa, sf, e1, p1,unet, n_cap,inum_nodes,nr,nz);
[ sa, sf ] = VBoundCond( sa, sf, e1, p1,unet, n_cap,inum_nodes,nr,nz);
[ sa, sf ] = PBoundCond( sa, sf,p1,n_cap,inum_nodes);

uvp = sa\sf;

uvp=qt*uvp;

i=1:inum_nodes;
uun = uvp(3*i-2,1);
vvn = uvp(3*i-1,1);
ppn = uvp(3*i,1);

for i=inum_nodes+1:num_nodes
    uun(i,1) = uvp(3*inum_nodes + 2*(i-inum_nodes)-1,1);
    vvn(i,1) = uvp(3*inum_nodes + 2*(i-inum_nodes),1);
end

fid = fopen('UPV_data.dat','w');
fprintf(fid,'TITLE = "mesh"\n ');
fprintf(fid,'VARIABLES =  X Y P V U\n');
fprintf(fid,'ZONE N=%6.0f,E=%6.0f,F=FEPOINT, ET=TRIANGLE\n',size(p,2),size(t,2));
for i = 1:size(p,2)
    fprintf (fid,'%20.12e\t %20.12e\t %20.12e\t %20.12e\t %20.12e\n', 1000*p(1,i), 1000*p(2,i), ppn(i,1) , 1000*vvn(i,1), 1000*uun(i,1));
end
for i = 1:size(t,2)
    fprintf(fid,'%6.0f\t  %6.0f \t %6.0f\n', t(1,i), t(2,i), t(3,i) );
end
fclose(fid);


figure(3);clf;
pdeplot(p,e,t,'xydata',uun(1:size(p,2),1),'contour','on','levels',20);
hold on;
title('Radial velocity (u)')
xlabel('r (m)') % x-axis label
ylabel('z (m)') % y-axis label
c = colorbar;
c.Label.String = '(m/s)';

figure(4);clf;
pdeplot(p,e,t,'xydata',vvn(1:size(p,2),1),'contour','on','levels',20);
hold on;
title('Axial velocity (v)')
xlabel('r (m)') % x-axis label
ylabel('z (m)') % y-axis label
c = colorbar;
c.Label.String = '(m/s)';


figure(5);clf;
pdeplot(p,e,t,'xydata',ppn(1:size(p,2),1),'contour','on','levels',20);
hold on;
title('Pressure (P)')
xlabel('r (m)') % x-axis label
ylabel('z (m)') % y-axis label
c = colorbar;
c.Label.String = '(N/m^2)';

%plotting comparison with Hu and Larson
CompHuL(p1,uun,WetAngRad,r_drop);

fprintf('done\n');
toc