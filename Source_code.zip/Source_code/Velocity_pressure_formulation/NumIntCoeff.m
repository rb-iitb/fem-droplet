function [ M, dSz, dSn,w,phi,Sphi,phiS ] = NumIntCoeff( )

% 7 point Gauss quadrature points and weights
l1(1) = 1/3;
l1(2) = 0.797426985353;
l1(3:4) = 0.101286507323;
l1(5) = 0.059715871789;
l1(6:7) = 0.470142064105;
l2(1) = 1/3;
l2(2) = 0.101286507323;
l2(3) = 0.797426985353;
l2(4) = 0.101286507323;
l2(5) = 0.470142064105;
l2(6) = 0.059715871789;
l2(7) = 0.470142064105;
w(1) = 0.225;
w(2:4) = 0.125939180544;
w(5:7) = 0.132394152788;

% % 4 point Gauss quadrature points and weights
% fl1(1)= 1/3;
% fl1(2)= 0.6;
% fl1(3:4)= 0.2;
% fl2(1)= 1/3;
% fl2(2)= 0.2;
% fl2(3)= 0.6;
% fl2(4)= 0.2;
% fw(1) = -27/48;
% fw(2:4) = 25/48;
% 
% % 1 point Gauss quadrature points and weights
% ol1=1/3;
% ol2=1/3;



S=zeros(6,7);
for i=1:7
    S(1,i)=l1(i)*(2*l1(i)-1);
    S(2,i)=l2(i)*(2*l2(i)-1);
    S(3,i)= (1-l1(i)-l2(i))*(1-2*l1(i)-2*l2(i));
    S(4,i)=4*l1(i)*l2(i);
    S(5,i)=4*l2(i)*(1-l1(i)-l2(i));
    S(6,i)=4*l1(i)*(1-l1(i)-l2(i));
end

phi=zeros(3,7);
for i=1:7
    phi(1,i)=l1(i);
    phi(2,i)=l2(i);
    phi(3,i)= (1-l1(i)-l2(i));
end


M=zeros(6,6);
for i=1:6
    for j= 1:6
        Sadd=0;
        for k= 1:7
            Sadd=Sadd+0.5*w(k)*(S(i,k)*S(j,k));
        end
         M(i,j)= Sadd;
    end
end


Sphi=zeros(6,3);
for i=1:6
    for j= 1:3
        Sadd=0;
        for k= 1:7
            Sadd=Sadd+0.5*w(k)*(S(i,k)*phi(j,k));
        end
         Sphi(i,j)= Sadd;
    end
end


phiS=zeros(3,6);
for i=1:3
    for j= 1:6
        Sadd=0;
        for k= 1:7
            Sadd=Sadd+0.5*w(k)*(S(j,k)*phi(i,k));
        end
         phiS(i,j)= Sadd;
    end
end


dSz=zeros(6,7);
for i=1:7
    dSz(1,i)= (4*l1(i)-1);
    dSz(2,i)= 0.0;
    dSz(3,i)= (-3+4*l1(i)+4*l2(i));
    dSz(4,i)= 4*l2(i);
    dSz(5,i)= (-4*l2(i));
    dSz(6,i)= 4*(1-2*l1(i)-l2(i));
end

dSn=zeros(6,7);
for i=1:7
    dSn(1,i)= 0.0;
    dSn(2,i)= (4*l2(i)-1);
    dSn(3,i)= (-3+4*l1(i)+4*l2(i));
    dSn(4,i)= 4*l1(i);
    dSn(5,i)= 4*(1-l1(i)-2*l2(i));
    dSn(6,i)= (-4*l1(i));
end


% fdSz=zeros(6,4);
% for i=1:4
%     fdSz(1,i)= (4*fl1(i)-1);
%     fdSz(2,i)= 0.0;
%     fdSz(3,i)= (-3+4*fl1(i)+4*fl2(i));
%     fdSz(4,i)= 4*fl2(i);
%     fdSz(5,i)= (-4*fl2(i));
%     fdSz(6,i)= 4*(1-2*fl1(i)-fl2(i));
% end
% 
% fdSn=zeros(6,4);
% for i=1:4
%     fdSn(1,i)= 0.0;
%     fdSn(2,i)= (4*fl2(i)-1);
%     fdSn(3,i)= (-3+4*fl1(i)+4*fl2(i));
%     fdSn(4,i)= 4*fl1(i);
%     fdSn(5,i)= 4*(1-fl1(i)-2*fl2(i));
%     fdSn(6,i)= (-4*fl1(i));
% end
% 
% 
% d1=0; d3=0; d4=0; d5=0; d6=0;
% for i=1:4
%     d1 = d1 + fw(i)*(4*fl1(i)-1);
%     %d2 = 0.0;
%     d3 = d3 + fw(i)*(-3+4*fl1(i)+4*fl2(i));
%     d4 = d4 + fw(i)*4*fl2(i);
%     d5 = d5+ fw(i)*(-4*fl2(i));
%     d6 = d6 + fw(i)*4*(1-2*fl1(i)-fl2(i));
% end
% wfdSz(1)= d1;
% wfdSz(2)= 0.0;
% wfdSz(3)= d3;
% wfdSz(4)= d4;
% wfdSz(5)= d5;
% wfdSz(6)= d6;
% 
% d2=0; d3=0; d4=0; d5=0; d6=0;
% for i=1:4
%     %d1 = 0.0;
%     d2 = d2 + fw(i)*(4*fl2(i)-1);
%     d3 = d3 + fw(i)*(-3+4*fl1(i)+4*fl2(i));
%     d4 = d4 + fw(i)*4*fl1(i);
%     d5 = d5+ fw(i)*4*(1-fl1(i)-2*fl2(i));
%     d6 = d6 + fw(i)*(-4*fl1(i));
% end
% wfdSn(1)= 0.0;
% wfdSn(2)= d2;
% wfdSn(3)= d3;
% wfdSn(4)= d4;
% wfdSn(5)= d5;
% wfdSn(6)= d6;
% odSz=zeros(6,1);
% 
% odSz(1,1)= (4*ol1-1);
% odSz(2,1)= 0.0;
% odSz(3,1)= (-3+4*ol1+4*ol2);
% odSz(4,1)= 4*ol2;
% odSz(5,1)= (-4*ol2);
% odSz(6,1)= 4*(1-2*ol1-ol2);
% 
% 
% odSn=zeros(6,1);
% 
% odSn(1,1)= 0.0;
% odSn(2,1)= (4*ol2-1);
% odSn(3,1)= (-3+4*ol1+4*ol2);
% odSn(4,1)= 4*ol1;
% odSn(5,1)= 4*(1-ol1-2*ol2);
% odSn(6,1)= (-4*ol1);




end

