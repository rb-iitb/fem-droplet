function [ M, Mb, Sai, dSz, dSn, odSz, odSn,tw,ow,wodSz,wodSn ] = NumIntCoeff( )

% % % % 7 point Gauss quadrature points and weights
% % % l1(1) = 1/3;
% % % l1(2) = 0.797426985353;
% % % l1(3:4) = 0.101286507323;
% % % l1(5) = 0.059715871789;
% % % l1(6:7) = 0.470142064105;
% % % l2(1) = 1/3;
% % % l2(2) = 0.101286507323;
% % % l2(3) = 0.797426985353;
% % % l2(4) = 0.101286507323;
% % % l2(5) = 0.470142064105;
% % % l2(6) = 0.059715871789;
% % % l2(7) = 0.470142064105;
% % % w(1) = 0.225;
% % % w(2:4) = 0.125939180544;
% % % w(5:7) = 0.132394152788;

% % 4 point Gauss quadrature points and weights
% fl1(1)= 1/3;
% fl1(2)= 0.6;
% fl1(3:4)= 0.2;
% fl2(1)= 1/3;
% fl2(2)= 0.2;
% fl2(3)= 0.6;
% fl2(4)= 0.2;
% fw(1) = -27/48;
% fw(2:4) = 25/48;

% 3 point Gauss quadrature points and weights
tl1(1:2)= 1/2;
tl1(3)=0.0;
tl2(1)=0.0;
tl2(2:3)=1/2;
tw(1:3)=1/3;

% 1 point Gauss quadrature points and weights
ol1=1/3;
ol2=1/3;
ow=1;

Sai=zeros(6,1);
for i=1:1
    Sai(1,i)=ol1(i)*(2*ol1(i)-1);
    Sai(2,i)=ol2(i)*(2*ol2(i)-1);
    Sai(3,i)= (1-ol1(i)-ol2(i))*(1-2*ol1(i)-2*ol2(i));
    Sai(4,i)=4*ol1(i)*ol2(i);
    Sai(5,i)=4*ol2(i)*(1-ol1(i)-ol2(i));
    Sai(6,i)=4*ol1(i)*(1-ol1(i)-ol2(i));
end



S=zeros(6,3);
for i=1:3
    S(1,i)=tl1(i)*(2*tl1(i)-1);
    S(2,i)=tl2(i)*(2*tl2(i)-1);
    S(3,i)= (1-tl1(i)-tl2(i))*(1-2*tl1(i)-2*tl2(i));
    S(4,i)=4*tl1(i)*tl2(i);
    S(5,i)=4*tl2(i)*(1-tl1(i)-tl2(i));
    S(6,i)=4*tl1(i)*(1-tl1(i)-tl2(i));
end


M=zeros(6,6);
for i=1:6
    for j= 1:6
        Sadd=0;
        for k= 1:3
            Sadd=Sadd+0.5*tw(k)*(S(i,k)*S(j,k));
        end
         M(i,j)= Sadd;
    end
end


Mb=zeros(6,6);
for i=1:6
    for j= 1:6
        Sadd=0;
        for k= 1:1
            Sadd=Sadd+0.5*ow(k)*(Sai(i,k)*Sai(j,k));
        end
         Mb(i,j)= Sadd;
    end
end



dSz=zeros(6,3);
for i=1:3
    dSz(1,i)= (4*tl1(i)-1);
    dSz(2,i)= 0.0;
    dSz(3,i)= (-3+4*tl1(i)+4*tl2(i));
    dSz(4,i)= 4*tl2(i);
    dSz(5,i)= (-4*tl2(i));
    dSz(6,i)= 4*(1-2*tl1(i)-tl2(i));
end

dSn=zeros(6,3);
for i=1:3
    dSn(1,i)= 0.0;
    dSn(2,i)= (4*tl2(i)-1);
    dSn(3,i)= (-3+4*tl1(i)+4*tl2(i));
    dSn(4,i)= 4*tl1(i);
    dSn(5,i)= 4*(1-tl1(i)-2*tl2(i));
    dSn(6,i)= (-4*tl1(i));
end


odSz=zeros(6,1);
for i=1:1
    odSz(1,i)= (4*ol1(i)-1);
    odSz(2,i)= 0.0;
    odSz(3,i)= (-3+4*ol1(i)+4*ol2(i));
    odSz(4,i)= 4*ol2(i);
    odSz(5,i)= (-4*ol2(i));
    odSz(6,i)= 4*(1-2*ol1(i)-ol2(i));
end

odSn=zeros(6,1);
for i=1:1
    odSn(1,i)= 0.0;
    odSn(2,i)= (4*ol2(i)-1);
    odSn(3,i)= (-3+4*ol1(i)+4*ol2(i));
    odSn(4,i)= 4*ol1(i);
    odSn(5,i)= 4*(1-ol1(i)-2*ol2(i));
    odSn(6,i)= (-4*ol1(i));
end

wodSz=zeros(6,1);

wodSz(1,1)= (4*ol1-1);
wodSz(2,1)= 0.0;
wodSz(3,1)= (-3+4*ol1+4*ol2);
wodSz(4,1)= 4*ol2;
wodSz(5,1)= (-4*ol2);
wodSz(6,1)= 4*(1-2*ol1-ol2);


wodSn=zeros(6,1);

wodSn(1,1)= 0.0;
wodSn(2,1)= (4*ol2-1);
wodSn(3,1)= (-3+4*ol1+4*ol2);
wodSn(4,1)= 4*ol1;
wodSn(5,1)= 4*(1-ol1-2*ol2);
wodSn(6,1)= (-4*ol1);

end

