function [unet,nr,nz] = Unet_interface(xnode,flux_node,mass_evap,H2,r_drop,rho,WetAngRad)
h0=H2*1e-3;
rc=(h0^2 + r_drop^2)/(2*h0);
hdot1=2*0.99*mass_evap/(rho*pi*(r_drop^2+h0^2));
rcdot=0.5*(1-(r_drop^2/h0^2))*hdot1;
for i=1:size(xnode,2)
    dhdt1(i)= (-1)*((rc/sqrt(rc^2-xnode(i)^2))-1)*rcdot + (-1)*hdot1;
end

for i=1:size(xnode,2)
    nr(i)=((xnode(i)*sin(WetAngRad))/r_drop);
    nz(i)=(sqrt(1-nr(i)^2));
    dhdt(i)= nz(i)*(-1)*hdot1*(((h0^4-r_drop^4)/(4*(h0^3)*(sqrt(((h0^2+r_drop^2)/(2*h0))^2-xnode(i)^2)))) + ((r_drop^2+h0^2)/(2*h0^2)));
end

ffu=flux_node./rho;
unet=dhdt+ffu;
end

