Steps to use solver

1. Open "FluidFlowInDroplet.m" file.

2. Use INPUT DATA section to feed in droplet, substrate and ambient parameters
