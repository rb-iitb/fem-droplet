function [flux_edge, flux_node, f, g, u] = SolveDiffusion(p, e, t)

global TfreeSurf Tnodes n_cap coeffA coeffB T_ambient

FreeSurfNodes = n_cap;
i = 1:1:FreeSurfNodes;
diff(:,i) = coeffA.*exp(-coeffB./(Tnodes(:,i)+273.15));
%diff(:,i) = coeffA.*exp(-coeffB./(T_ambient+273.15));
%diff(:,i) = 2.61e-5;

k = 1:1:FreeSurfNodes-1;
diff_edge(:,k) = coeffA.*exp(-coeffB./(TfreeSurf(:,k)+273.15));
%diff_edge(:,k) = coeffA.*exp(-coeffB./(T_ambient+273.15));  
%diff_edge(:,k) = 2.61e-5;



k = 1:size(t,2);
x =   (p(1,t(1,k))  + p(1,t(2,k))  + p(1,t(3,k)))/3;

u = assempde('BoundCondDiffusion',p,e,t,x,0,0); % solve axisymmteric pde

[ux, uy] = pdegrad(p,t,u);  % Calculate gradient ux and uy

c=sqrt(ux.^2+uy.^2);
d=pdeprtni(p,t,c);

flux(:,1:FreeSurfNodes) = 0;
for i =1:1:FreeSurfNodes
    k=FreeSurfNodes+1-i;
    %k=FreeSurfNodes+4-i;
    flux(:,i) = d(k,:);
end

%Flux at edges
flux_edge(:,1:FreeSurfNodes-1) = 0;
for i =1:1:FreeSurfNodes-1
flux_edge(:,i) = diff_edge(:,i)*(flux(:,i) + flux(:,i+1))*0.5; %Avg flux at the edge
end

%Flux at nodes
flux_node(:,1:FreeSurfNodes)=0.0;
for i =1:1:FreeSurfNodes
flux_node(:,i) = diff(:,i)*flux(:,i);
end

f  = (-1).*pdeprtni(p,t,ux);
g = (-1).*pdeprtni(p,t,uy);

return;

