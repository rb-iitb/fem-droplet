function [ sa, sf ,qt] = UBoundCond( sa, sf, e, p,unet, n_cap,nrr,nzz)

num=2*size(p,2);
qq=eye(num);

sanew=sa;
for i=1:size(e,2)
    %free surafce boundary condition
    if e(6,i) < n_cap
        iu1 = 2*e(1,i)-1;
        iu2 = 2*e(2,i)-1;
        iv1 = 2*e(1,i);
        iv2 = 2*e(2,i);
        
        nr = nrr(e(1,i));
        nz = nzz(e(1,i));
               
        sanew(:,iu1)= sa(:,iu1)*nr + sa(:,iv1)*nz;
        sanew(:,iv1)= sa(:,iu1)*(-1*nz) + sa(:,iv1)*nr;
        
        qq(iu1,iu1) = nr;
        qq(iu1,iv1) = nz;
        qq(iv1,iu1) = -1*nz;
        qq(iv1,iv1) = nr;
        
%         sf(iu1,1) =  sf(iu1,1)+u1*nr;
%         sf(iv1,1) = sf(iv1,1)+u1*nz;
        
        nr = 0.5*(nrr(e(1,i))+ nrr(e(3,i)));
        nz = 0.5*(nzz(e(1,i))+ nzz(e(3,i)));
               
        sanew(:,iu2)= sa(:,iu2)*nr + sa(:,iv2)*nz;
        sanew(:,iv2)= sa(:,iu2)*(-1*nz) + sa(:,iv2)*nr;
        qq(iu2,iu2) = nr;
        qq(iu2,iv2) = nz;
        qq(iv2,iu2) = -1*nz;
        qq(iv2,iv2) = nr;
        
%         sf(iu2,1) = sf(iu2,1)+u2*nr;
%         sf(iv2,1) = sf(iv2,1)+u2*nz;
    end
end

clear sa;
saneww=sanew;
for i=1:size(e,2)
    %free surafce boundary condition
    if e(6,i) < n_cap
        iu1 = 2*e(1,i)-1;
        iu2 = 2*e(2,i)-1;
        iv1 = 2*e(1,i);
        iv2 = 2*e(2,i);
      
        nr = nrr(e(1,i));
        nz = nzz(e(1,i));
        
        saneww(iu1,:)= sanew(iu1,:)*nr + sanew(iv1,:)*nz;
        saneww(iv1,:)= sanew(iu1,:)*(-1*nz) + sanew(iv1,:)*nr;

        nr = 0.5*(nrr(e(1,i))+ nrr(e(3,i)));
        nz = 0.5*(nzz(e(1,i))+ nzz(e(3,i)));
        
        saneww(iu2,:)= sanew(iu2,:)*nr + sanew(iv2,:)*nz;
        saneww(iv2,:)= sanew(iu2,:)*(-1*nz) + sanew(iv2,:)*nr;
    end
end
clear sanew;
qt=transpose(qq);
% san=qq*(sa*qt);
sa=saneww;
% sf=qq*sf;

    
for i=1:size(e,2)

    %interface boundary condition
     if e(6,i)< n_cap
        iu1 = 2*e(1,i)-1;
        iu2 = 2*e(2,i)-1;
        u1  = unet(e(1,i));
        u2  = 0.5*(unet(e(1,i))+unet(e(3,i)));
        
        for ju = 1:num;
            sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u1;
            sa(iu1,ju) = 0.0;
            sa(ju,iu1) = 0.0;
            
            sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u2;
            sa(iu2,ju) = 0.0;
            sa(ju,iu2) = 0.0;
        end
        
        sa(iu1,iu1) = 1.0;
        sf(iu1,1)    = u1;
        sa(iu2,iu2) = 1.0;
        sf(iu2,1)    = u2;
        
    end
    
    %axisymmetric boundary condition
     if e(6,i)== n_cap
        iu1 = 2*e(1,i)-1;
        iu2 = 2*e(2,i)-1;
        u  = 0.0;
        
        for ju = 1:num;
            sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
            sa(iu1,ju) = 0.0;
            sa(ju,iu1) = 0.0;
            
            sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u;
            sa(iu2,ju) = 0.0;
            sa(ju,iu2) = 0.0;
        end
        
        sa(iu1,iu1) = 1.0;
        sf(iu1,1)    = u;
        sa(iu2,iu2) = 1.0;
        sf(iu2,1)    = u;
        
    end
    
    %bottom boundary condition
    if e(6,i)> n_cap
        iu1 = 2*e(1,i)-1;
        iu2 = 2*e(2,i)-1;
        u  = 0.0;
        
        for ju = 1:num;
            sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
            sa(iu1,ju) = 0.0;
            sa(ju,iu1) = 0.0;
            
            sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u;
            sa(iu2,ju) = 0.0;
            sa(ju,iu2) = 0.0;
        end
        
        sa(iu1,iu1) = 1.0;
        sf(iu1,1)    = u;
        sa(iu2,iu2) = 1.0;
        sf(iu2,1)    = u;
    end
     
end

% %-------droplet axisymmetric top node boundary condition------------
% iu = 2*n_cap-1;
% u  = unet(n_cap);
% 
% for ju = 1:num;
%     sf(ju,1) = sf(ju,1)-sa(ju,iu)*u;
%     sa(iu,ju) = 0.0;
%     sa(ju,iu) = 0.0;
% end
% 
% sa(iu,iu) = 1.0;
% sf(iu,1)    = u;

end

