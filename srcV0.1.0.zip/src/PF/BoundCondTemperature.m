function [q,g,h,r] = BoundCondTemperature(p,e,u,time)
% This function creates the boundary condition
% h*u = r --Dirichlet boundary condition
% n.(c*del(u)) + q*u = g --Neumann boundary condition

global T_substrate H1 Latent_heat jevp

ne = size(e,2); % Number of edges on boundary
q = zeros(1,ne);
g = zeros(1,ne);
h = zeros(1,2*ne);
r = zeros(1,2*ne);


sub_bott=H1*1e-3;
count = 0;
for k = 1:ne
    x1 = p(1,e(1,k)); % x at starting point of edge
    x2 = p(1,e(2,k)); % x at ending point of edge
    xm = (x1+x2)*0.5;
    y1 = p(2,e(1,k)); % y at starting point of edge
    y2 = p(2,e(2,k)); % y at ending point of edge
    
    %-- for bottom boundary (Boundary DE) -
    if (y1 == -sub_bott && y2 == -sub_bott)
        h(k) = 1;
        h(k+ne) = 1;
        r(k)    = T_substrate;
        r(k+ne) = T_substrate;
    end
    
    % -- arc boundary (Boundary AB) --
    if (e(6,k) == 2 && e(7,k) == 0)
        count = count + 1;
        %g(k) = -(1e-5)*Latent_heat*xm;
        g(k) = -jevp(:,count)*Latent_heat*xm;
    end
end
return;