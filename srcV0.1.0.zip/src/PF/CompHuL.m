function [] = CompHuL(p1,uun,WetAngRad,r_drop)
figure(6); clf;

number=num2str(1/10);
ouputfile=strcat('comp_with HuL\','r_',number,'.csv');
A=csvread(ouputfile,6,0);
plot(A(:,1), A(:,2),'rs')
hold on;

number=num2str(6/10);
ouputfile=strcat('comp_with HuL\','r_',number,'.csv');
A=csvread(ouputfile,6,0);
plot(A(:,1), A(:,2),'g^')

number=num2str(9/10);
ouputfile=strcat('comp_with HuL\','r_',number,'.csv');
A=csvread(ouputfile,6,0);
plot(A(:,1), A(:,2),'bd')

F = scatteredInterpolant((1000*p1(1,:))',(1000*p1(2,:))',1000*uun);

h1=sqrt((r_drop/sin(WetAngRad))^2 - (r_drop*0.1)^2) - (r_drop/tan(WetAngRad));
xq=1000*r_drop*0.1*ones(100,1);
yq=1000*transpose(linspace(0,h1));
ue = F(xq,yq) ;
plot(ue, yq,'-')

fid = fopen('ur0_1.dat','w');
fprintf(fid,'VARIABLES =  ur h\n');
for i = 1:size(yq,1)
    fprintf (fid,'%20.12e\t %20.12e\n', ue(i,1), yq(i,1));

end
fclose(fid);



h1=sqrt((r_drop/sin(WetAngRad))^2 - (r_drop*0.6)^2) - (r_drop/tan(WetAngRad));
xq=1000*r_drop*0.6*ones(100,1);
yq=1000*transpose(linspace(0,h1));
ue = F(xq,yq) ;
plot(ue, yq,'-')

fid = fopen('ur0_6.dat','w');
fprintf(fid,'VARIABLES =  ur h\n');
for i = 1:size(yq,1)
    fprintf (fid,'%20.12e\t %20.12e\n', ue(i,1), yq(i,1));

end
fclose(fid);


h1=sqrt((r_drop/sin(WetAngRad))^2 - (r_drop*0.9)^2) - (r_drop/tan(WetAngRad));
xq=1000*r_drop*0.9*ones(100,1);
yq=1000*transpose(linspace(0,h1));
ue = F(xq,yq) ;
plot(ue, yq,'-')

fid = fopen('ur0_9.dat','w');
fprintf(fid,'VARIABLES =  ur h\n');
for i = 1:size(yq,1)
    fprintf (fid,'%20.12e\t %20.12e\n', ue(i,1), yq(i,1));

end
fclose(fid);




xlabel('u (mm/s)')
ylabel('z (mm)')
legend('Hu & Larson, r=0.1','Hu & Larson, r=0.6','Hu & Larson, r=0.9','Present, r=0.1','Present, r=0.6','Present, r=0.9');


end