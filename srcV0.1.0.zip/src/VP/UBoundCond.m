function [ sa, sf, qt ] = UBoundCond( sa, sf, e, p,unet, n_cap,inum_nodes,nrr,nzz)

% global u_bottom u_top u_right u_left

num=2*size(p,2)+inum_nodes;

qq=eye(num);

sanew=sa;
for i=1:size(e,2)
    %free surafce boundary condition
    if e(6,i) < n_cap
        iu1 = 3*e(1,i)-2;
        iu2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes)-1;
        iv1 = 3*e(1,i)-1;
        iv2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes);
        
        nr = nrr(e(1,i));
        nz = nzz(e(1,i));
        
        sanew(:,iu1)= sa(:,iu1)*nr + sa(:,iv1)*nz;
        sanew(:,iv1)= sa(:,iu1)*(-1*nz) + sa(:,iv1)*nr;
        
        qq(iu1,iu1) = nr;
        qq(iu1,iv1) = nz;
        qq(iv1,iu1) = -1*nz;
        qq(iv1,iv1) = nr;
        
        nr = 0.5*(nrr(e(1,i))+ nrr(e(3,i)));
        nz = 0.5*(nzz(e(1,i))+ nzz(e(3,i)));
        
        sanew(:,iu2)= sa(:,iu2)*nr + sa(:,iv2)*nz;
        sanew(:,iv2)= sa(:,iu2)*(-1*nz) + sa(:,iv2)*nr;
        
        qq(iu2,iu2) = nr;
        qq(iu2,iv2) = nz;
        qq(iv2,iu2) = -1*nz;
        qq(iv2,iv2) = nr;
    end
end

clear sa;
saneww=sanew;
for i=1:size(e,2)
    %free surafce boundary condition
    if e(6,i) < n_cap
        iu1 = 3*e(1,i)-2;
        iu2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes)-1;
        iv1 = 3*e(1,i)-1;
        iv2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes);
        
        nr = nrr(e(1,i));
        nz = nzz(e(1,i));
        
        saneww(iu1,:)= sanew(iu1,:)*nr + sanew(iv1,:)*nz;
        saneww(iv1,:)= sanew(iu1,:)*(-1*nz) + sanew(iv1,:)*nr;
        
        nr = 0.5*(nrr(e(1,i))+ nrr(e(3,i)));
        nz = 0.5*(nzz(e(1,i))+ nzz(e(3,i)));
        
        saneww(iu2,:)= sanew(iu2,:)*nr + sanew(iv2,:)*nz;
        saneww(iv2,:)= sanew(iu2,:)*(-1*nz) + sanew(iv2,:)*nr;
    end
end
clear sanew;
qt=transpose(qq);
% san=qq*(sa*qt);
sa=saneww;
% sf=qq*sf;

for i=1:size(e,2)
    
    %interface boundary condition
    if e(6,i)< n_cap
        iu1 = 3*e(1,i)-2;
        iu2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes)-1;
        u1  = unet(e(1,i));
        u2  = 0.5*(unet(e(1,i))+unet(e(3,i)));
        
        for ju = 1:num;
            sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u1;
            sa(iu1,ju) = 0.0;
            sa(ju,iu1) = 0.0;
            
            sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u2;
            sa(iu2,ju) = 0.0;
            sa(ju,iu2) = 0.0;
        end
        
        sa(iu1,iu1) = 1.0;
        sf(iu1,1)    = u1;
        sa(iu2,iu2) = 1.0;
        sf(iu2,1)    = u2;
        
    end
    
    
    %axisymmetric boundary condition
    if e(6,i)== n_cap
        iu1 = 3*e(1,i)-2;
        iu2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes)-1;
        u  = 0.0;
        
        for ju = 1:num;
            sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
            sa(iu1,ju) = 0.0;
            sa(ju,iu1) = 0.0;
            
            sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u;
            sa(iu2,ju) = 0.0;
            sa(ju,iu2) = 0.0;
        end
        
        sa(iu1,iu1) = 1.0;
        sf(iu1,1)    = u;
        sa(iu2,iu2) = 1.0;
        sf(iu2,1)    = u;
        
    end
    
    %bottom boundary condition
    if e(6,i)> n_cap
        iu1 = 3*e(1,i)-2;
        iu2 = 3*inum_nodes + 2*(e(2,i)-inum_nodes)-1;
        u  = 0.0;
        
        for ju = 1:num;
            sf(ju,1) = sf(ju,1)-sa(ju,iu1)*u;
            sa(iu1,ju) = 0.0;
            sa(ju,iu1) = 0.0;
            
            sf(ju,1) = sf(ju,1)-sa(ju,iu2)*u;
            sa(iu2,ju) = 0.0;
            sa(ju,iu2) = 0.0;
        end
        
        sa(iu1,iu1) = 1.0;
        sf(iu1,1)    = u;
        sa(iu2,iu2) = 1.0;
        sf(iu2,1)    = u;
    end
    
    
    
end


% %-------droplet axisymmetric top node boundary condition------------
% iu = 3*n_cap-2;
% u  = -1*ur(n_cap);
%
% for ju = 1:num;
%     sf(ju,1) = sf(ju,1)-sa(ju,iu)*u;
%     sa(iu,ju) = 0.0;
%     sa(ju,iu) = 0.0;
% end
%
% sa(iu,iu) = 1.0;
% sf(iu,1)    = u;

end

