Version 1.1

For penalty function formulation

Run src>PF>FluidFlowInDroplet.m

For velocity pressure formulation

Run src>VP>FluidFlowInDroplet.m